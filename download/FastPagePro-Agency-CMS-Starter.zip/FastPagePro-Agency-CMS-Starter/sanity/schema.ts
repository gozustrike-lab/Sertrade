// @ts-nocheck — Sanity schema types are validated by Studio, not Next.js
// ============================================================
// FAST PAGE PRO STUDIO v2.0 — Schema Entry Point
// Imports all document types and exports them as a single array.
// ============================================================

import siteSettings from "./schemas/siteSettings";
import serviceCategory from "./schemas/serviceCategory";
import service from "./schemas/service";
import project from "./schemas/project";
import teamMember from "./schemas/teamMember";
import testimonial from "./schemas/testimonial";
import partner from "./schemas/partner";
import heroSlide from "./schemas/heroSlide";
import stat from "./schemas/stat";
import studioGuide from "./schemas/guia";

export const schemaTypes = [
  siteSettings,
  serviceCategory,
  service,
  project,
  teamMember,
  testimonial,
  partner,
  heroSlide,
  stat,
  studioGuide,
];
